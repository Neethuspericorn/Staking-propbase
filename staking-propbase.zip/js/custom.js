$(document).ready(function () {
	$('#navToggleBtn').click(function () {
		$('.body-wrapper').toggleClass('nav-collapse');
	});
});